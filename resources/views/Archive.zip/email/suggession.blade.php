<strong>Name: </strong> {{ $name }}<br/>
<strong>Email: </strong> {{ $email }}<br/>
<strong>Phone: </strong> {{ $phone }}<br/>
<strong>Type: </strong> {{ $type }}<br/>
<strong>Url: </strong> {{ $url }}<br/>
<p><strong>suggession: </strong> {{ $suggession }}</p>
